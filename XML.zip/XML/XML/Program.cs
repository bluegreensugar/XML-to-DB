﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static XML.DataBase;


namespace XML
{
    internal class Program
    {

        static void createOrderProduct(long id_product, int id_order, int quantity, DataBase db)
        {
            MySqlCommand commandOrder;
            commandOrder = new MySqlCommand("INSERT shop.order_product SET id_order=@O, id_product=@P, count=@C", db.getConnection());
            commandOrder.Parameters.Add("@O", MySqlDbType.UInt32).Value = id_order;
            commandOrder.Parameters.Add("@P", MySqlDbType.UInt64).Value = id_product;
            commandOrder.Parameters.Add("@C", MySqlDbType.UInt32).Value = quantity;

         

            try
            {
                commandOrder.ExecuteNonQuery();
                
            }
            catch
            {
                Exception error = new Exception("Ошибка добавления ORDER");
                throw error;
            }
        }
        static void xmlLoad(DataBase db)
        {
            XDocument xmlDoc = new XDocument();
            string path = Path.GetFullPath(Directory.GetCurrentDirectory() + "\\..\\..\\..\\");
            xmlDoc = XDocument.Load(path + "/shop.xml");
            int id_user;
            MySqlCommand command;
            Console.WriteLine("Документ для обработки: ");
            Console.WriteLine(xmlDoc.ToString());
            XElement orders = xmlDoc.Element("orders");
            if (!orders.IsEmpty)
            {
                foreach (XElement order in orders.Elements("order"))
                {

                    Console.WriteLine("ORDER");
                    XElement id = order.Element("no");
                    int id_Int = Convert.ToInt32(id.Value);
                    XElement reg_date = order.Element("reg_date");
                    XElement sum = order.Element("sum");
                    double sumFl = Convert.ToDouble(sum?.Value);
                    sumFl = Math.Round(sumFl, 2);
                    Console.WriteLine(id?.Value + " - id");
                    Console.WriteLine(reg_date?.Value + " - reg_date");
                    Console.WriteLine(sum?.Value + " - sum");
                    Console.WriteLine(" ---- ");



                    foreach (XElement user in order.Elements("user"))
                    {

                        Console.WriteLine("USER");
                        XElement fio = user.Element("fio");
                        XElement email = user.Element("email");
                        Console.WriteLine(fio?.Value + " - fio");
                        Console.WriteLine(email?.Value + " - email");


                        command = new MySqlCommand("INSERT user SET name=@N, email=@E", db.getConnection());
                        command.Parameters.Add("@N", MySqlDbType.VarChar).Value = fio?.Value;
                        command.Parameters.Add("@E", MySqlDbType.VarChar).Value = email?.Value;
                        
                        try
                        {
                            command.ExecuteNonQuery();
                            id_user = (int)Convert.ToUInt64(command.LastInsertedId);
                           

                        }
                        catch
                        {
                            Exception error = new Exception("Ошибка добавления");
                            throw error;
                        }



                        //----------------------если мы упали в ноду пользователя, значит можно создавать запись заказа
                        command = new MySqlCommand("INSERT shop.order SET id_order=@O, id_user=@U, data=@D, sum=@S", db.getConnection());
                        command.Parameters.Add("@O", MySqlDbType.UInt64).Value = id_Int;
                        command.Parameters.Add("@U", MySqlDbType.UInt64).Value = id_user;
                        command.Parameters.Add("@D", MySqlDbType.Date).Value = reg_date?.Value;
                        command.Parameters.Add("@S", MySqlDbType.Float).Value = sumFl;

                        try
                        {
                            command.ExecuteNonQuery();
                            Console.WriteLine("INSERT ORDER");



                        }
                        catch
                        {
                            Exception error = new Exception("Ошибка добавления ORDER");
                            throw error;
                        }
                        

                    }


                    foreach (XElement product in order.Elements("product"))
                    {
                       
                        XElement quantity = product.Element("quantity");
                        int quanInt = Convert.ToInt32(quantity.Value);
                        XElement name = product.Element("name");
                        XElement price = product.Element("price");

                        Console.WriteLine(quantity?.Value + " - quantity");
                        Console.WriteLine(name?.Value + " - name");
                        Console.WriteLine(price?.Value + " - price");


                        command = new MySqlCommand("INSERT product SET name=@N, cost=@P", db.getConnection());
                        command.Parameters.Add("@N", MySqlDbType.VarChar).Value = name?.Value;
                        //приведение типа 
                        //string str = price?.Value;
                        double priceFl = Convert.ToDouble(price?.Value);
                        priceFl = Math.Round(priceFl, 2);

                        command.Parameters.Add("@P", MySqlDbType.Float).Value = priceFl;

                        try
                        {
                            command.ExecuteNonQuery();
                           
                        }
                        catch
                        {
                            Exception error = new Exception("Ошибка добавления");
                            throw error;
                        }
                        createOrderProduct(command.LastInsertedId, id_Int, quanInt, db);

                    }

                }
            }

        }

        static void Main(string[] args)
        {
            DataBase db = new DataBase();
            db.openConnection();
            DataTable table = new DataTable();
            xmlLoad(db);
        }


    }
}
